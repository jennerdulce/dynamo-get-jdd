# dynamo-get-jdd
Deployment Package for 'get' lambda function
